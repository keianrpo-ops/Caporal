
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  user: any;
}

const Navbar: React.FC<NavbarProps> = ({ user }) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menú', path: '/menu' },
    { name: 'Pedido Online', path: '/menu' },
    { name: 'Reservas', path: '/#reservas' },
    { name: 'Cotizaciones', path: '/cotizaciones' },
    { name: 'Experiencias', path: '/#experiencias' },
  ];

  const isActive = (path: string) => location.pathname === path || (location.hash && path.includes(location.hash));

  return (
    <nav className="fixed w-full z-50 bg-deepBlack text-bone border-b border-burgundy/40 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-24">
          {/* Brand Logo matching the image */}
          <Link to="/" className="flex flex-col items-center group">
             <div className="flex flex-col items-center leading-none">
                <span className="text-[8px] uppercase tracking-[0.4em] font-bold text-stone-400 group-hover:text-burgundy transition-colors">EL</span>
                <span className="font-serif text-2xl tracking-tighter uppercase">CAPORAL</span>
                <div className="flex items-center gap-2 mt-1">
                   <div className="h-[1px] w-4 bg-burgundy"></div>
                   <span className="text-[10px] font-bold tracking-widest text-burgundy">1961</span>
                   <div className="h-[1px] w-4 bg-burgundy"></div>
                </div>
             </div>
          </Link>

          {/* Desktop Links */}
          <div className="hidden xl:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path.startsWith('/#') ? '/' : link.path}
                onClick={() => {
                  if (link.path.startsWith('/#')) {
                    setTimeout(() => {
                      const id = link.path.substring(2);
                      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }
                }}
                className={`transition-all hover:text-burgundy tracking-widest text-[11px] font-bold uppercase border-b border-transparent hover:border-burgundy pb-1 ${
                  isActive(link.path) ? 'text-burgundy border-burgundy' : 'text-bone/70'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* User Icons */}
          <div className="flex items-center gap-6">
            <Link to={user ? "/perfil" : "/auth"} className="text-stone-400 hover:text-burgundy transition-all flex items-center gap-3">
              <div className={`p-2.5 rounded-full border border-stone-800 ${user ? 'bg-burgundy/20 border-burgundy text-burgundy' : ''}`}>
                <User size={18} />
              </div>
              <div className="hidden lg:flex flex-col items-start leading-none">
                <span className="text-[9px] uppercase tracking-widest font-black">
                  {user ? 'Mi Cuenta' : 'Ingresar'}
                </span>
                <span className="text-[8px] text-stone-500 italic mt-0.5">Club Caporal</span>
              </div>
            </Link>
            
            <Link to="/menu" className="relative text-stone-400 hover:text-burgundy transition-all p-2.5 rounded-full border border-stone-800">
              <ShoppingBag size={18} />
              <span className="absolute top-0 right-0 bg-burgundy text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold border border-deepBlack">0</span>
            </Link>

            <div className="xl:hidden">
              <button onClick={() => setIsOpen(!isOpen)} className="text-bone hover:text-burgundy p-2 transition-transform active:scale-90">
                {isOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Links */}
      {isOpen && (
        <div className="xl:hidden bg-deepBlack/98 border-t border-burgundy/20 animate-fade-in-down h-screen overflow-y-auto">
          <div className="px-6 py-12 space-y-6 text-center">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path.startsWith('/#') ? '/' : link.path}
                onClick={() => {
                  setIsOpen(false);
                  if (link.path.startsWith('/#')) {
                    setTimeout(() => {
                      const id = link.path.substring(2);
                      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }
                }}
                className="block py-4 text-sm font-bold tracking-[0.3em] uppercase text-bone border-b border-white/5 hover:text-burgundy transition-colors"
              >
                {link.name}
              </Link>
            ))}
            <div className="pt-12">
               <p className="text-[10px] text-stone-500 uppercase tracking-widest mb-4 italic">"Historia y cocina de autor"</p>
               <div className="flex justify-center gap-6">
                 <div className="w-10 h-10 border border-stone-800 rounded-full flex items-center justify-center text-stone-500">IG</div>
                 <div className="w-10 h-10 border border-stone-800 rounded-full flex items-center justify-center text-stone-500">FB</div>
               </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
