
import React from 'react';

const Preloader: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-burgundy">
      <div className="relative flex flex-col items-center animate-fade-in">
        {/* Horse Head Silhouette stylized like the logo */}
        <div className="mb-6 relative w-40 h-40 flex items-center justify-center">
           <svg viewBox="0 0 200 200" className="w-full h-full fill-bone opacity-90">
             <path d="M100,20 C120,20 140,35 145,55 C150,75 140,110 110,135 L100,180 L90,135 C60,110 50,75 55,55 C60,35 80,20 100,20 Z" fill="none" stroke="currentColor" strokeWidth="1" className="opacity-20" />
             {/* Simple horse head representation */}
             <path d="M105,65 c0,0 20,-5 25,15 c5,20 -10,35 -20,40 c0,0 -5,-15 -15,-15 c-10,0 -15,15 -15,15 c-10,-5 -25,-20 -20,-40 c5,-20 25,-15 25,-15 c0,0 5,-10 10,-10 c5,0 10,10 10,10 z" />
           </svg>
           {/* Decorative ring around horse */}
           <div className="absolute inset-0 border-[1px] border-bone/20 rounded-full scale-110 animate-ping"></div>
        </div>

        <div className="text-center text-bone">
          <span className="text-sm uppercase tracking-[0.5em] font-light block mb-2 opacity-80">EL</span>
          <h1 className="text-5xl md:text-6xl font-serif tracking-tighter uppercase mb-2">
            CAPORAL
          </h1>
          <div className="flex items-center justify-center gap-4">
             <div className="h-[1px] w-8 bg-bone/40"></div>
             <span className="text-xs uppercase tracking-[0.3em] font-bold">1961</span>
             <div className="h-[1px] w-8 bg-bone/40"></div>
          </div>
          <p className="text-bone/60 font-serif italic mt-6 text-sm tracking-widest">
            "Historia y cocina de autor"
          </p>
        </div>
      </div>
      
      <div className="absolute bottom-12 w-48 h-[2px] bg-white/10 overflow-hidden">
        <div className="h-full bg-bone animate-progress-indefinite"></div>
      </div>
      
      <style>{`
        @keyframes progress-indefinite {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-progress-indefinite {
          animation: progress-indefinite 2s infinite linear;
        }
      `}</style>
    </div>
  );
};

export default Preloader;
