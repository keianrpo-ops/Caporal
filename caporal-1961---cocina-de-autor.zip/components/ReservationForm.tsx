
import React, { useState } from 'react';
import { supabase } from '../supabaseClient';
import { Calendar, Users, Phone, User, Clock, CheckCircle2 } from 'lucide-react';

const ReservationForm: React.FC = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    celular: '',
    fecha: '',
    hora: '',
    personas: 2,
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { error: insertError } = await supabase
        .from('reservas')
        .insert([formData]);

      if (insertError) throw insertError;

      setSuccess(true);
      // Construct WhatsApp message
      const text = `Hola! Quiero confirmar mi reserva:\nNombre: ${formData.nombre}\nPersonas: ${formData.personas}\nFecha: ${formData.fecha}\nHora: ${formData.hora}\nCelular: ${formData.celular}`;
      const waUrl = `https://wa.me/573218912246?text=${encodeURIComponent(text)}`;
      
      setTimeout(() => {
        window.open(waUrl, '_blank');
      }, 2000);

    } catch (err: any) {
      setError(err.message || 'Error al procesar la reserva. Intente de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center p-12 bg-burgundy/5 rounded-lg border border-burgundy/20 animate-fade-in">
        <CheckCircle2 size={64} className="text-burgundy mx-auto mb-6" />
        <h3 className="text-2xl font-serif text-deepBlack mb-4">¡Reserva Solicitada con Éxito!</h3>
        <p className="text-stone-600 mb-8">Redirigiendo a WhatsApp para confirmación inmediata...</p>
        <button 
          onClick={() => setSuccess(false)}
          className="text-burgundy font-semibold hover:underline"
        >
          Hacer otra reserva
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-8 md:p-12 shadow-2xl rounded-sm border border-stone-200">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-2">
          <label className="text-xs uppercase tracking-widest font-semibold text-stone-500">Nombre Completo</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input
              type="text"
              required
              className="w-full pl-10 pr-4 py-3 border-b-2 border-stone-200 focus:border-burgundy outline-none transition-all"
              placeholder="Ej. Juan Pérez"
              value={formData.nombre}
              onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs uppercase tracking-widest font-semibold text-stone-500">Celular de Contacto</label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input
              type="tel"
              required
              className="w-full pl-10 pr-4 py-3 border-b-2 border-stone-200 focus:border-burgundy outline-none transition-all"
              placeholder="Ej. 321 000 0000"
              value={formData.celular}
              onChange={(e) => setFormData({ ...formData, celular: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs uppercase tracking-widest font-semibold text-stone-500">Fecha</label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input
              type="date"
              required
              min={new Date().toISOString().split('T')[0]}
              className="w-full pl-10 pr-4 py-3 border-b-2 border-stone-200 focus:border-burgundy outline-none transition-all"
              value={formData.fecha}
              onChange={(e) => setFormData({ ...formData, fecha: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs uppercase tracking-widest font-semibold text-stone-500">Hora</label>
          <div className="relative">
            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input
              type="time"
              required
              className="w-full pl-10 pr-4 py-3 border-b-2 border-stone-200 focus:border-burgundy outline-none transition-all"
              value={formData.hora}
              onChange={(e) => setFormData({ ...formData, hora: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2 md:col-span-2">
          <label className="text-xs uppercase tracking-widest font-semibold text-stone-500">Número de Personas</label>
          <div className="relative">
            <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <select
              required
              className="w-full pl-10 pr-4 py-3 border-b-2 border-stone-200 focus:border-burgundy outline-none transition-all bg-transparent"
              value={formData.personas}
              onChange={(e) => setFormData({ ...formData, personas: parseInt(e.target.value) })}
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                <option key={n} value={n}>{n} {n === 1 ? 'Persona' : 'Personas'}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-deepBlack text-bone py-4 uppercase tracking-[0.2em] font-semibold hover:bg-burgundy transition-all disabled:opacity-50"
      >
        {loading ? 'Procesando...' : 'Confirmar Reserva'}
      </button>
    </form>
  );
};

export default ReservationForm;
