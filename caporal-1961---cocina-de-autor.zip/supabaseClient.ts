
import { createClient } from '@supabase/supabase-js';

// Intentamos obtener las variables de varios lugares posibles para máxima compatibilidad
const getEnv = (key: string) => {
  // @ts-ignore
  return (typeof process !== 'undefined' && process.env?.[key]) || 
         // @ts-ignore
         (typeof import.meta !== 'undefined' && import.meta.env?.[key]) || 
         '';
};

const supabaseUrl = getEnv('VITE_SUPABASE_URL');
const supabaseAnonKey = getEnv('VITE_SUPABASE_ANON_KEY');

// Validación básica para evitar que createClient falle catastróficamente
const isValidUrl = (url: string) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn("⚠️ Caporal 1961: Faltan credenciales de Supabase. Verifica tu archivo .env o variables de entorno.");
}

// Exportamos el cliente. Si la URL no es válida, devolvemos un proxy o manejamos el error
// para que el resto de la app no muera al importar este archivo.
export const supabase = isValidUrl(supabaseUrl) 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null as any;
