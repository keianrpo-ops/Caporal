
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { MenuItem, Reservation } from '../types';
import { 
  LogOut, 
  Calendar, 
  BookOpen, 
  Plus, 
  Trash2, 
  Check, 
  X as CloseIcon, 
  RefreshCcw,
  User,
  Users,
  Smartphone
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'reservas' | 'menu'>('reservas');
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Menu Form State
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [newMenu, setNewMenu] = useState({
    categoria: 'Platos de Autor',
    nombre_plato: '',
    descripcion: '',
    precio: 0,
    imagen_url: ''
  });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    if (activeTab === 'reservas') {
      const { data } = await supabase.from('reservas').select('*').order('created_at', { ascending: false });
      setReservations(data || []);
    } else {
      const { data } = await supabase.from('menu').select('*').order('categoria', { ascending: true });
      setMenuItems(data || []);
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const updateReservationStatus = async (id: string, status: 'confirmada' | 'cancelada') => {
    const { error } = await supabase.from('reservas').update({ estado: status }).eq('id', id);
    if (!error) fetchData();
  };

  const deleteMenuItem = async (id: string) => {
    if (window.confirm('¿Eliminar este plato del menú?')) {
      const { error } = await supabase.from('menu').delete().eq('id', id);
      if (!error) fetchData();
    }
  };

  const addMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from('menu').insert([newMenu]);
    if (!error) {
      setShowAddMenu(false);
      setNewMenu({ categoria: 'Platos de Autor', nombre_plato: '', descripcion: '', precio: 0, imagen_url: '' });
      fetchData();
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-deepBlack text-bone flex flex-col hidden md:flex">
        <div className="p-8 border-b border-burgundy/20">
          <h2 className="font-serif text-xl tracking-widest uppercase">Admin Panel</h2>
          <p className="text-stone-500 text-xs italic">Caporal 1961</p>
        </div>
        <nav className="flex-grow p-4 space-y-2">
          <button
            onClick={() => setActiveTab('reservas')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm transition-all text-sm uppercase tracking-widest ${
              activeTab === 'reservas' ? 'bg-burgundy text-white' : 'hover:bg-burgundy/10 text-stone-400'
            }`}
          >
            <Calendar size={18} /> Reservas
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm transition-all text-sm uppercase tracking-widest ${
              activeTab === 'menu' ? 'bg-burgundy text-white' : 'hover:bg-burgundy/10 text-stone-400'
            }`}
          >
            <BookOpen size={18} /> Gestionar Menú
          </button>
        </nav>
        <button
          onClick={handleLogout}
          className="m-4 flex items-center justify-center gap-2 px-4 py-3 text-stone-400 hover:text-white transition-all text-xs uppercase tracking-widest border border-stone-800"
        >
          <LogOut size={16} /> Cerrar Sesión
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-12 overflow-y-auto">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-serif text-deepBlack uppercase tracking-tighter">
            {activeTab === 'reservas' ? 'Gestión de Reservas' : 'Administrar Menú'}
          </h1>
          <button 
            onClick={fetchData} 
            className="p-2 text-stone-400 hover:text-burgundy transition-all"
            title="Refrescar"
          >
            <RefreshCcw size={20} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>

        {activeTab === 'reservas' ? (
          <div className="grid grid-cols-1 gap-6">
            {reservations.length === 0 ? (
              <p className="text-stone-500 italic">No hay reservas registradas.</p>
            ) : (
              reservations.map((res) => (
                <div key={res.id} className="bg-white p-6 shadow-md border-l-4 border-burgundy flex flex-col md:flex-row justify-between items-center gap-4">
                  <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-6 w-full">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-stone-400 mb-1">Cliente</p>
                      <p className="font-serif font-bold flex items-center gap-2"><User size={14} className="text-burgundy" /> {res.nombre}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-stone-400 mb-1">Contacto</p>
                      <p className="text-sm flex items-center gap-2"><Smartphone size={14} /> {res.celular}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-stone-400 mb-1">Fecha & Hora</p>
                      <p className="text-sm font-semibold">{res.fecha} | {res.hora}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-stone-400 mb-1">Personas</p>
                      <p className="text-sm flex items-center gap-2"><Users size={14} /> {res.personas}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {res.estado === 'pendiente' ? (
                      <>
                        <button 
                          onClick={() => updateReservationStatus(res.id, 'confirmada')}
                          className="p-2 bg-green-100 text-green-700 rounded-full hover:bg-green-700 hover:text-white transition-all"
                          title="Confirmar"
                        >
                          <Check size={20} />
                        </button>
                        <button 
                          onClick={() => updateReservationStatus(res.id, 'cancelada')}
                          className="p-2 bg-red-100 text-red-700 rounded-full hover:bg-red-700 hover:text-white transition-all"
                          title="Cancelar"
                        >
                          <CloseIcon size={20} />
                        </button>
                      </>
                    ) : (
                      <span className={`px-4 py-1 rounded-full text-[10px] uppercase font-bold tracking-widest ${
                        res.estado === 'confirmada' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {res.estado}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div>
            <div className="flex justify-end mb-8">
              <button 
                onClick={() => setShowAddMenu(!showAddMenu)}
                className="bg-burgundy text-white px-6 py-3 rounded-sm flex items-center gap-2 uppercase tracking-widest text-xs font-bold shadow-lg hover:scale-105 transition-all"
              >
                {showAddMenu ? <CloseIcon size={18} /> : <Plus size={18} />}
                {showAddMenu ? 'Cerrar' : 'Agregar Nuevo Plato'}
              </button>
            </div>

            {showAddMenu && (
              <form onSubmit={addMenuItem} className="bg-white p-8 mb-12 shadow-xl rounded-sm border-t-4 border-burgundy animate-fade-in-down grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-stone-400">Nombre del Plato</label>
                  <input 
                    required 
                    className="w-full p-3 border border-stone-200 outline-none focus:border-burgundy"
                    value={newMenu.nombre_plato}
                    onChange={(e) => setNewMenu({...newMenu, nombre_plato: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-stone-400">Categoría</label>
                  <select 
                    className="w-full p-3 border border-stone-200 outline-none focus:border-burgundy bg-transparent"
                    value={newMenu.categoria}
                    onChange={(e) => setNewMenu({...newMenu, categoria: e.target.value})}
                  >
                    <option value="Entradas">Entradas</option>
                    <option value="Platos de Autor">Platos de Autor</option>
                    <option value="Gourmet">Gourmet</option>
                    <option value="Tradición">Tradición</option>
                    <option value="Coctelería">Coctelería</option>
                    <option value="Postres">Postres</option>
                  </select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] uppercase font-bold text-stone-400">Descripción</label>
                  <textarea 
                    className="w-full p-3 border border-stone-200 outline-none focus:border-burgundy h-24"
                    value={newMenu.descripcion}
                    onChange={(e) => setNewMenu({...newMenu, descripcion: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-stone-400">Precio (Pesos CO)</label>
                  <input 
                    type="number"
                    required 
                    className="w-full p-3 border border-stone-200 outline-none focus:border-burgundy"
                    value={newMenu.precio}
                    onChange={(e) => setNewMenu({...newMenu, precio: Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-stone-400">URL Imagen (Unsplash u otro)</label>
                  <input 
                    className="w-full p-3 border border-stone-200 outline-none focus:border-burgundy"
                    placeholder="https://..."
                    value={newMenu.imagen_url}
                    onChange={(e) => setNewMenu({...newMenu, imagen_url: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <button type="submit" className="w-full bg-deepBlack text-white py-4 uppercase tracking-[0.2em] font-bold hover:bg-burgundy transition-all">
                    Guardar Plato
                  </button>
                </div>
              </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {menuItems.map((item) => (
                <div key={item.id} className="bg-white p-6 shadow-md relative group">
                  <button 
                    onClick={() => deleteMenuItem(item.id)}
                    className="absolute top-4 right-4 p-2 bg-red-100 text-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600 hover:text-white"
                  >
                    <Trash2 size={16} />
                  </button>
                  <span className="text-burgundy text-[10px] uppercase font-bold tracking-widest">{item.categoria}</span>
                  <h3 className="font-serif text-xl mb-2 mt-1">{item.nombre_plato}</h3>
                  <p className="text-stone-500 text-sm italic mb-4 line-clamp-2">{item.descripcion}</p>
                  <p className="font-bold text-lg">${Number(item.precio).toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
