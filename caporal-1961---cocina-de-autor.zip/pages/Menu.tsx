
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { MenuItem, MenuCategory } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Utensils, AlertCircle, ShoppingBag } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const categories: MenuCategory[] = ['Entradas', 'Platos de Autor', 'Gourmet', 'Tradición', 'Coctelería', 'Postres'];

const MenuPage: React.FC = () => {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<MenuItem[]>([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('cat') || 'All';
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchMenu();
  }, []);

  useEffect(() => {
    if (activeCategory === 'All') {
      setFilteredItems(items);
    } else {
      setFilteredItems(items.filter(i => i.categoria === activeCategory));
    }
  }, [activeCategory, items]);

  const fetchMenu = async () => {
    if (!supabase) {
      setError(true);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('menu')
        .select('*')
        .order('categoria', { ascending: true });

      if (error) throw error;
      setItems(data || []);
    } catch (err) {
      console.error(err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryChange = (cat: string) => {
    setSearchParams({ cat });
  };

  return (
    <div className="min-h-screen bg-bone pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-burgundy uppercase tracking-[0.4em] text-xs font-bold mb-4 block">Carta Gastronómica</span>
          <h1 className="text-6xl font-serif text-deepBlack mb-6 tracking-tighter uppercase">Nuestra Cocina</h1>
          <p className="text-stone-500 italic max-w-2xl mx-auto font-light leading-relaxed text-lg">
            Seleccione una categoría para explorar nuestras creaciones de autor. 
            Cada ingrediente es seleccionado por su frescura y origen.
          </p>
          <div className="w-16 h-1 bg-burgundy mx-auto mt-8"></div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-20">
          <button
            onClick={() => handleCategoryChange('All')}
            className={`px-8 py-3 rounded-sm text-xs font-bold uppercase tracking-widest transition-all shadow-md ${
              activeCategory === 'All' 
              ? 'bg-burgundy text-white' 
              : 'bg-white text-stone-600 hover:bg-stone-50'
            }`}
          >
            Todos los platos
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleCategoryChange(cat)}
              className={`px-8 py-3 rounded-sm text-xs font-bold uppercase tracking-widest transition-all shadow-md ${
                activeCategory === cat 
                ? 'bg-burgundy text-white' 
                : 'bg-white text-stone-600 hover:bg-stone-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-20 text-stone-400 font-serif italic animate-pulse text-2xl">
            Preparando la experiencia Caporal...
          </div>
        ) : error ? (
          <div className="text-center py-20 bg-white shadow-2xl rounded-sm border border-stone-200 max-w-lg mx-auto">
            <AlertCircle size={48} className="text-burgundy mx-auto mb-4" />
            <h3 className="text-2xl font-serif mb-4 uppercase">No se pudo cargar el menú</h3>
            <p className="text-stone-500 italic mb-8">Estamos experimentando problemas técnicos.</p>
            <button onClick={fetchMenu} className="text-burgundy font-bold text-xs uppercase tracking-widest border-b border-burgundy">Reintentar</button>
          </div>
        ) : (
          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12"
          >
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white rounded-sm overflow-hidden shadow-2xl border border-stone-100 group flex flex-col h-full"
                >
                  <div className="h-72 overflow-hidden relative shrink-0">
                    <img 
                      src={item.imagen_url || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c'} 
                      alt={item.nombre_plato} 
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-deepBlack/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                       <div className="bg-bone text-deepBlack px-6 py-2 rounded-sm text-[10px] font-bold uppercase tracking-widest shadow-2xl">Ver Ingredientes</div>
                    </div>
                    <div className="absolute top-6 right-6 bg-burgundy/95 text-bone px-5 py-2 rounded-sm text-sm font-bold shadow-2xl border border-bone/10">
                      ${Number(item.precio).toLocaleString('es-CO')}
                    </div>
                  </div>
                  <div className="p-10 flex flex-col flex-grow">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-6 h-[1px] bg-burgundy"></div>
                      <span className="text-burgundy text-[10px] uppercase tracking-[0.3em] font-bold italic">{item.categoria}</span>
                    </div>
                    <h3 className="text-3xl font-serif text-deepBlack mb-4 leading-tight">{item.nombre_plato}</h3>
                    <p className="text-stone-500 font-light text-base leading-relaxed mb-8 italic flex-grow">
                      "{item.descripcion}"
                    </p>
                    <button className="w-full py-4 bg-deepBlack text-bone text-[10px] uppercase tracking-[0.4em] font-bold hover:bg-burgundy transition-all flex items-center justify-center gap-3 mt-auto">
                      <ShoppingBag size={14} /> Añadir al Pedido
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}

        {!loading && !error && filteredItems.length === 0 && (
          <div className="text-center py-20 bg-white/50 border border-stone-200 rounded-sm">
            <Utensils size={48} className="text-stone-300 mx-auto mb-6" />
            <p className="text-stone-500 italic text-xl">Nuestros chefs están preparando nuevas delicias para esta categoría.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuPage;
