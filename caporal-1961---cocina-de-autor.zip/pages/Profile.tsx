
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { Star, Award, Calendar, RefreshCcw, LogOut, Gift } from 'lucide-react';

interface ProfilePageProps {
  user: any;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user }) => {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfile();
  }, [user]);

  const fetchProfile = async () => {
    const { data, error } = await supabase
      .from('perfiles_clientes')
      .select('*')
      .eq('id', user.id)
      .single();

    if (!error) setProfile(data);
    setLoading(false);
  };

  const handleLogout = () => supabase.auth.signOut();

  if (loading) return <div className="pt-32 text-center font-serif italic text-stone-400">Cargando perfil elite...</div>;

  return (
    <div className="min-h-screen pt-32 pb-20 px-4 bg-bone">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* User Card */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-deepBlack text-bone p-10 rounded-sm shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-burgundy/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
              <div className="relative z-10 text-center">
                <div className="w-24 h-24 bg-burgundy rounded-full mx-auto mb-6 flex items-center justify-center text-4xl font-serif border-4 border-white/10">
                  {profile?.nombre?.[0] || 'C'}
                </div>
                <h2 className="text-2xl font-serif mb-1 uppercase tracking-tighter">{profile?.nombre || 'Miembro Caporal'}</h2>
                <p className="text-stone-400 text-xs uppercase tracking-widest mb-6">{profile?.nivel_lealtad} Member</p>
                
                <div className="flex justify-center gap-8 border-y border-white/10 py-6 mb-8">
                  <div>
                    <p className="text-[10px] uppercase font-bold text-stone-500 mb-1">Puntos</p>
                    <p className="text-2xl font-serif text-burgundy">{profile?.puntos || 0}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-bold text-stone-500 mb-1">Visitas</p>
                    <p className="text-2xl font-serif text-burgundy">{profile?.visitas || 0}</p>
                  </div>
                </div>

                <button onClick={handleLogout} className="text-xs uppercase tracking-widest font-bold text-stone-500 hover:text-burgundy transition-all flex items-center gap-2 mx-auto">
                  <LogOut size={14} /> Cerrar Sesión
                </button>
              </div>
            </div>
          </div>

          {/* Loyalty & Rewards */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h1 className="text-4xl font-serif text-deepBlack uppercase tracking-tighter mb-8">Mis Recompensas</h1>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-8 border-l-4 border-burgundy shadow-lg rounded-sm group hover:scale-[1.02] transition-all">
                  <Gift className="text-burgundy mb-4" size={32} />
                  <h4 className="font-serif text-xl uppercase tracking-widest mb-2">Bienvenida</h4>
                  <p className="text-stone-500 text-sm font-light italic mb-4">15% de descuento en tu próximo plato de autor.</p>
                  <span className="bg-green-100 text-green-700 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">Disponible</span>
                </div>
                <div className="bg-white p-8 border-l-4 border-stone-300 shadow-lg rounded-sm opacity-60">
                  <Award className="text-stone-400 mb-4" size={32} />
                  <h4 className="font-serif text-xl uppercase tracking-widest mb-2">Quinto Caporal</h4>
                  <p className="text-stone-500 text-sm font-light italic mb-4">Postre gratis al completar 5 visitas.</p>
                  <span className="bg-stone-100 text-stone-500 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">En Progreso</span>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-serif text-deepBlack uppercase tracking-widest mb-6 border-b border-stone-200 pb-2">Historial de Visitas</h2>
              <div className="bg-white shadow-xl rounded-sm p-8 text-center">
                <Calendar size={48} className="text-stone-200 mx-auto mb-4" />
                <p className="text-stone-400 font-light italic">Próximamente verás aquí el registro de tus cenas en la casona.</p>
                <button onClick={fetchProfile} className="mt-6 text-burgundy font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 mx-auto">
                  <RefreshCcw size={14} /> Sincronizar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
