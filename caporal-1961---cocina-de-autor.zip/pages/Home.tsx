
import React from 'react';
import { motion } from 'framer-motion';
import ReservationForm from '../components/ReservationForm';
import { ChefHat, History, Award, Star, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <div 
          className="absolute inset-0 z-0 parallax-bg opacity-40 bg-fixed bg-center bg-cover" 
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=2070")' }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-deepBlack/90 to-bone/10 z-1"></div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
          className="relative z-10 text-center px-4"
        >
          <span className="text-burgundy font-serif italic text-xl mb-6 block tracking-[0.2em] uppercase opacity-90">Legado Gastronómico</span>
          <div className="flex flex-col items-center mb-8">
            <span className="text-bone/60 text-sm uppercase tracking-[0.8em] font-light mb-2">EL</span>
            <h1 className="text-7xl md:text-9xl font-serif text-bone tracking-tighter uppercase leading-none">Caporal</h1>
            <div className="flex items-center gap-4 mt-2">
              <div className="h-[2px] w-12 bg-burgundy"></div>
              <span className="text-burgundy font-bold text-2xl tracking-widest">1961</span>
              <div className="h-[2px] w-12 bg-burgundy"></div>
            </div>
          </div>
          
          <p className="text-stone-300 max-w-2xl mx-auto font-serif italic text-lg md:text-2xl leading-relaxed tracking-widest py-6 px-4 border-t border-white/10">
            "Historia y cocina de autor"
          </p>

          <div className="mt-16 flex flex-col sm:flex-row gap-6 justify-center">
            <button 
              onClick={() => scrollToSection('reservas')}
              className="bg-burgundy text-white px-12 py-5 rounded-sm hover:bg-burgundy/90 hover:scale-105 transition-all uppercase tracking-[0.3em] text-xs font-black shadow-2xl"
            >
              Reservar Mesa
            </button>
            <button 
              onClick={() => scrollToSection('historia')}
              className="border border-bone/30 text-bone px-12 py-5 rounded-sm hover:bg-bone hover:text-deepBlack transition-all uppercase tracking-[0.3em] text-xs font-black"
            >
              Nuestra Historia
            </button>
          </div>
        </motion.div>
        
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-40">
           <div className="w-[1px] h-16 bg-bone"></div>
        </div>
      </section>

      {/* Misión & Visión Section */}
      <section id="historia" className="py-40 bg-bone scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div className="relative group">
              <div className="absolute -inset-6 border border-burgundy/10 rounded-lg group-hover:border-burgundy/30 transition-all duration-700"></div>
              <img 
                src="https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=1974" 
                alt="Caporal 1961 Interior" 
                className="rounded-sm shadow-2xl relative z-10 grayscale hover:grayscale-0 transition-all duration-1000 object-cover h-[600px] w-full"
              />
              <div className="absolute -bottom-10 -right-10 bg-burgundy text-white p-12 rounded-sm hidden md:block z-20 shadow-2xl">
                <History size={48} className="mb-6 opacity-40" />
                <h3 className="font-serif text-4xl mb-1 tracking-tighter">63 Años</h3>
                <p className="text-[10px] opacity-70 uppercase tracking-[0.4em] font-black">Tradición de Autor</p>
              </div>
            </div>
            
            <div className="space-y-20">
              <div className="animate-fade-in">
                <span className="text-burgundy uppercase tracking-[0.5em] text-[10px] font-black mb-6 block">Nuestra Alma</span>
                <h2 className="text-6xl font-serif text-deepBlack mb-10 uppercase tracking-tighter">Misión</h2>
                <p className="text-stone-700 leading-relaxed text-2xl font-light italic border-l-8 border-burgundy/20 pl-10 py-2">
                  "Preservar y evolucionar la herencia culinaria desde 1961, ofreciendo una cocina de autor que rinde homenaje a nuestras raíces a través de técnicas contemporáneas y un servicio excepcional".
                </p>
              </div>
              
              <div>
                <h2 className="text-6xl font-serif text-deepBlack mb-10 uppercase tracking-tighter">Visión</h2>
                <p className="text-stone-700 leading-relaxed text-2xl font-light italic border-l-8 border-burgundy/20 pl-10 py-2">
                  "Convertirnos en el referente regional de la alta cocina de autor, siendo reconocidos por la perfecta armonía entre la arquitectura colonial y la innovación gastronómica".
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Loyalty Program Section */}
      <section className="py-32 bg-deepBlack relative overflow-hidden">
        <div className="absolute inset-0 bg-burgundy/10 opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
          <div className="w-24 h-[1px] bg-burgundy mx-auto mb-10"></div>
          <Star size={56} className="text-burgundy mx-auto mb-8 animate-pulse" />
          <h2 className="text-5xl md:text-7xl font-serif text-bone mb-8 uppercase tracking-tighter">Club Caporal</h2>
          <p className="text-stone-400 max-w-3xl mx-auto mb-16 text-xl font-light leading-relaxed italic">
            Regístrate hoy y obtén un <span className="text-burgundy font-bold">15% de descuento</span> en tu próxima experiencia. 
            Acumula puntos por cada cena y accede a eventos exclusivos de cata y maridaje privado.
          </p>
          <Link 
            to="/auth" 
            className="inline-flex items-center gap-6 bg-burgundy text-white px-16 py-6 uppercase tracking-[0.4em] text-xs font-black hover:bg-burgundy/80 transition-all rounded-sm shadow-2xl group"
          >
            Unirme al Club
            <ArrowRight size={20} className="group-hover:translate-x-3 transition-transform" />
          </Link>
          <div className="w-24 h-[1px] bg-burgundy mx-auto mt-20"></div>
        </div>
      </section>

      {/* Highlights */}
      <section className="py-40 bg-bone" id="experiencias">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-24">
             <span className="text-burgundy uppercase tracking-[0.5em] text-[10px] font-black mb-4 block">El Arte de Servir</span>
             <h2 className="text-6xl font-serif uppercase tracking-tighter text-deepBlack">Experiencias</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-20">
            <div className="group text-center">
              <div className="mb-10 w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto group-hover:bg-burgundy shadow-xl transition-all duration-500">
                <ChefHat size={40} className="text-burgundy group-hover:text-white transition-colors" />
              </div>
              <h4 className="font-serif text-3xl mb-6 uppercase tracking-widest text-deepBlack">Catering Elite</h4>
              <p className="text-stone-500 font-light leading-relaxed italic px-4 mb-8">Propuestas gastronómicas de autor para bodas y eventos corporativos de alto nivel.</p>
              <Link to="/cotizaciones" className="text-burgundy font-black text-[10px] uppercase tracking-[0.3em] border-b-2 border-burgundy/20 pb-1 hover:border-burgundy transition-all">Solicitar Cotización</Link>
            </div>
            <div className="group text-center">
              <div className="mb-10 w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto group-hover:bg-burgundy shadow-xl transition-all duration-500">
                <History size={40} className="text-burgundy group-hover:text-white transition-colors" />
              </div>
              <h4 className="font-serif text-3xl mb-6 uppercase tracking-widest text-deepBlack">Casona 1961</h4>
              <p className="text-stone-500 font-light leading-relaxed italic px-4">Nuestra arquitectura colonial de arcos históricos ofrece un ambiente de elegancia atemporal.</p>
            </div>
            <div className="group text-center">
              <div className="mb-10 w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto group-hover:bg-burgundy shadow-xl transition-all duration-500">
                <Award size={40} className="text-burgundy group-hover:text-white transition-colors" />
              </div>
              <h4 className="font-serif text-3xl mb-6 uppercase tracking-widest text-deepBlack">Alta Cocina</h4>
              <p className="text-stone-500 font-light leading-relaxed italic px-4">Creaciones únicas que fusionan la tradición con la vanguardia culinaria de nuestro chef.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Reservations */}
      <section id="reservas" className="py-40 bg-white scroll-mt-24">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-20">
            <span className="text-burgundy uppercase tracking-[0.5em] text-[10px] font-black mb-4 block">Confirmación Inmediata</span>
            <h2 className="text-7xl font-serif text-deepBlack mb-8 uppercase tracking-tighter">Reservar</h2>
            <div className="w-32 h-[1px] bg-burgundy mx-auto mb-8"></div>
            <p className="text-stone-500 italic text-2xl font-light">"Prepare sus sentidos para una velada extraordinaria".</p>
          </div>
          <ReservationForm />
        </div>
      </section>
    </div>
  );
};

export default Home;
