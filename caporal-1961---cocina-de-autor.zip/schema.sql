
-- SQL Schema for Caporal 1961 Restaurant (Extended)

-- Table for Menu items
CREATE TABLE IF NOT EXISTS menu (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  categoria TEXT NOT NULL,
  nombre_plato TEXT NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10, 2) NOT NULL,
  imagen_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Table for Reservations
CREATE TABLE IF NOT EXISTS reservas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre TEXT NOT NULL,
  celular TEXT NOT NULL,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  personas INTEGER NOT NULL,
  estado TEXT DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'confirmada', 'cancelada')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Table for Catering Quotes
CREATE TABLE IF NOT EXISTS cotizaciones_catering (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre_cliente TEXT NOT NULL,
  email TEXT NOT NULL,
  telefono TEXT NOT NULL,
  tipo_evento TEXT NOT NULL,
  fecha_evento DATE,
  num_personas INTEGER,
  mensaje TEXT,
  estado TEXT DEFAULT 'pendiente',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Table for Client Profiles (Loyalty Program)
CREATE TABLE IF NOT EXISTS perfiles_clientes (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nombre TEXT,
  celular TEXT,
  puntos INTEGER DEFAULT 0,
  visitas INTEGER DEFAULT 0,
  nivel_lealtad TEXT DEFAULT 'Bronce',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservas ENABLE ROW LEVEL SECURITY;
ALTER TABLE cotizaciones_catering ENABLE ROW LEVEL SECURITY;
ALTER TABLE perfiles_clientes ENABLE ROW LEVEL SECURITY;

-- Policies for menu
CREATE POLICY "Public read access for menu" ON menu FOR SELECT USING (true);
CREATE POLICY "Admin full access for menu" ON menu FOR ALL USING (auth.role() = 'authenticated');

-- Policies for reservations
CREATE POLICY "Public can make reservations" ON reservas FOR INSERT WITH CHECK (true);
CREATE POLICY "Admin full access for reservations" ON reservas FOR ALL USING (auth.role() = 'authenticated');

-- Policies for catering quotes
CREATE POLICY "Public can request quotes" ON cotizaciones_catering FOR INSERT WITH CHECK (true);
CREATE POLICY "Admin full access for quotes" ON cotizaciones_catering FOR ALL USING (auth.role() = 'authenticated');

-- Policies for client profiles
CREATE POLICY "Users can view own profile" ON perfiles_clientes FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON perfiles_clientes FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admin can view all profiles" ON perfiles_clientes FOR ALL USING (auth.role() = 'authenticated');
