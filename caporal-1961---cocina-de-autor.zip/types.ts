
export interface MenuItem {
  id: string;
  categoria: string;
  nombre_plato: string;
  descripcion: string;
  precio: number;
  imagen_url: string;
  created_at?: string;
}

export interface Reservation {
  id: string;
  nombre: string;
  celular: string;
  fecha: string;
  hora: string;
  personas: number;
  estado: 'pendiente' | 'confirmada' | 'cancelada';
  created_at?: string;
}

export type MenuCategory = 'Entradas' | 'Platos de Autor' | 'Gourmet' | 'Tradición' | 'Coctelería' | 'Postres';
